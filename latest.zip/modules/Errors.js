const Discord = require("discord.js")
const errors = {
    1: "No results",
    2: "Sorry, but something went wrong",
    3: "Something went really wrong and you should blame the bot dev",
    4: "Sorry, but this command can only be used in NSFW channels",
    5: "Sorry, but this command is owner only",
    6: "Sorry, but you can only use this command in a server"
}
module.exports.errorinfo = async function (channel, id) {
    embed = new Discord.MessageEmbed()
    .setAuthor("Error","https://raw.githubusercontent.com/Xandertron/xandertron.github.io/master/error.png")
    .setTitle(`**${errors[id]}**`)
    .setFooter("(Error #"+id+", report with the bug command if you think this is an issue!)")
    channel.send(embed)
}