const Discord = require("discord.js");

module.exports.cleanID = function (query) {
  if (!query || typeof query !== "string") return;
  match = query.match(/^<@!?(\d+)>$/)
  if (match) {
    return id = match[1]
  }
  return query
}

module.exports.resolveChannel = async function (search, guild) {
  let channel = null;
  if (!search || typeof search !== "string") return;
  //Try to search using ID
  if (search.match(/^#&!?(\d+)$/)) {
    let id = search.match(/^#&!?(\d+)$/)[1];
    channel = guild.channels.cache.get(id);
    if (channel) return channel;
  }
  //Got fucking lazy so I just removed the <#>
  if (search.includes("<#")) {
    let firstChannel = search.replace("<#", "");
    let channelID = firstChannel.replace(">", "");
    let channel = guild.channels.cache.get(channelID);
    if (channel) return channel;
  }
  //Try to search it using name
  channel = guild.channels.cache.find((c) => search.toLowerCase() === c.name.toLowerCase());
  if (channel) return channel;
  //Try to find the channel itself
  channel = guild.channels.cache.get(search);
  return channel;
};


module.exports.fetchCmdList = async function (client, message, data) {
  let category = await client.commands.map(x => x.category);
  let embed = new Discord.MessageEmbed()
    .setAuthor("List of available commands")
    .setColor(data.config.color)
    .setFooter(client.randomfooter());

  let catList = []
  let inDM = (!message.guild)
  for (let i = 0; i < category.length; i++) {
    if (!catList.includes(category[i])) {
      catList.push(category[i])
      let cmdList = await client.commands.filter(
        x =>
          (x.category === category[i]) &
          (x.hidden !== true) &
          (x.ownerOnly !== true) &
          (x.enabled === true) &
          (x.serverOnly !== inDM))
        .map(x => x.name).join(", ")
      if (cmdList.length > 0) {
        embed.addField(category[i], "```" + cmdList + "```")
      }
    }
  }

  return message.channel.send(embed)

};
