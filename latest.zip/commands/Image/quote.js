const Discord = require("discord.js");
const sa = require("superagent");

module.exports = {
    //Command Information
    name: "quote",
    description: "Generate an inspirational quote from inspirobot.me",
    usage: "quote",
    enabled: true,
    aliases: [],
    category: "Images",
    memberPermissions: [],
    botPermissions: [ "SEND_MESSAGES", "EMBED_LINKS" ],
    nsfw: false,
    cooldown: 5000,
    ownerOnly: false,

    async execute(client, message, args, data) {

        let api = await sa.get("https://inspirobot.me/api?generate=true")
        let embed = new Discord.MessageEmbed()
        .setTitle(message.author.tag)
        .setImage(api.text)
        .setColor(data.config.color)
        .setFooter("Provided by inspirobot.me")
        return message.channel.send(embed)

    },
};
