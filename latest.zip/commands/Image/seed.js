const Discord = require('discord.js');
const exec = require("child_process").execFile;
const mcseed = require("mcseed");
const Jimp = require("jimp");
Jimp.read('resources/background.png', (err, lenna) => {
    if (err) throw err;
    background = lenna
    //console.log(background)
})

module.exports = {
    //Command Information
    name: "seed",
    description: "Shows a biome map of a minecraft seed",
    usage: "seed <seed (number or text)> [x] [z]",
    enabled: true,
    aliases: [],
    category: "Images",
    memberPermissions: [],
    botPermissions: [ "SEND_MESSAGES", "EMBED_LINKS" ],
    nsfw: false,
    cooldown: 3000,
    ownerOnly: false,

    async execute(client, message, args, data) {
        seed = mcseed(args[0])
        exec('resources/BiomeMapper', [seed, args[1], args[2]], function(err, cdata) { 
            if(err){
                console.log(err)
            }
            f = cdata.toString().split(" ")
            Jimp.read(f[6]).then(biomemap => {
                var bgclone = background.clone()
                bgclone.composite(biomemap,48,48)
                bgclone.getBuffer(Jimp.MIME_PNG, function(_,result) {
                    var x = parseInt(args[1])
                    var z = parseInt(args[2])
                    x = (isNaN(x)) ? 0 : x
                    z = (isNaN(z)) ? 0 : z
                    extra = (args[1] !== undefined) ? ` @ X: ${x} | Z: ${z}` : ` @ X: 0 | Z: 0`
                    x = x / 256
                    z = -z / 256
                    const attachment = new Discord.MessageAttachment(result, "image.png")
                    let embed = new Discord.MessageEmbed()
                    .setTitle(`Seed: ${seed}`+ extra)
                    .setDescription(`View it in a browser [here](https://xandertron.github.io/seedmap/?seed=${seed}`+((args[1] !== undefined) ? `#5/${z}/${x})` : ")"))
                    .attachFiles(attachment)
                    .setImage("attachment://image.png")
                    .setColor(data.config.color)
                    .setFooter(client.randomfooter())
                    message.channel.send(embed)
                    //console.log(embed)
                })
            }).catch(err => {
                console.log("Error during seed: "+err)
                client.errors.errorinfo(message.channel, 2)
            })
        })
    }
}