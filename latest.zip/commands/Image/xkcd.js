const Discord = require("discord.js");
const xkcd = require("xkcd-helper");

module.exports = {
    //Command Information
    name: "xkcd",
    description: "Get the latest or a specific xkcd comic",
    usage: "xkcd\nxkcd [id]\nxkcd random",
    enabled: true,
    aliases: [],
    category: "Images",
    memberPermissions: [],
    botPermissions: ["SEND_MESSAGES", "EMBED_LINKS"],
    nsfw: false,
    cooldown: 3000,
    ownerOnly: false,

    async execute(client, message, args, data) {
        try {
            let comicdata
            if (!args[0]) {
                comicdata = await xkcd.getLatest()
            }
            else if (args[0] == "random") {
                comicdata = await xkcd.getRandom()
            }
            else if (args[0]) {
                if (parseInt(args[0])) {
                    comicdata = await xkcd.getComic(parseInt(args[0]))
                }
            }
            let embed = new Discord.MessageEmbed()
                .setTitle(`xkcd #${comicdata.num}: ${comicdata.safe_title}`)
                .setDescription(`${comicdata.alt}\n\n**Date:** ${comicdata.month}/${comicdata.day}/${comicdata.year}\n`)
                .setImage(comicdata.img)
                .setColor(data.config.color)
                .setFooter(client.randomfooter())
            return message.channel.send(embed)
        }
        catch (e) {
            client.errors.errorinfo(message.channel, 2)
            console.log(e)
        }
    },
};
