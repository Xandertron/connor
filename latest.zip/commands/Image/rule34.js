const Discord = require('discord.js')
const posts = require("rule34js").posts

module.exports = {
  //Command Information
  name: "rule34",
  description: "Request a image from rule34.xxx",
  usage: "rule34 <tag>",
  enabled: false,
  aliases: ["r34"],
  category: "Images",
  memberPermissions: [],
  botPermissions: ["SEND_MESSAGES", "EMBED_LINKS", ],
  nsfw: true,
  cooldown: 3000,
  ownerOnly: false,

  async execute(client, message, args, data) {

    response = await posts({ tags: args })
    let r34posts = response.posts
    if(r34posts === undefined){
      return client.errors.errorinfo(message.channel, 1)
    }
    else if (r34posts.file_url) {
      //console.log(r34posts)
      let embed = new Discord.MessageEmbed()
        .setTitle('Rule34 Search requested by: ' + message.author.tag)
        .setImage(r34posts.file_url)
        .setColor(data.config.color)
        .setFooter("Page 1/1")
      return message.channel.send(embed)
    }
    let numresults = r34posts.length
    let embed = new Discord.MessageEmbed()
      .setTitle('Rule34 Search requested by: ' + message.author.tag)
      .setImage(r34posts[0].file_url)
      .setColor(data.config.color)
      .setFooter("Page 1/"+numresults)
    msg = await message.channel.send(embed)
    msg.react("⬅️").then(() => msg.react("➡️")).then(() => {
      const filter = (reaction, user) => {
        return user.id === message.author.id
      }
      const collector = msg.createReactionCollector(filter, { idle: 30000, dispose: true })
      let index = 0
      collector.on('collect', (reaction, user) => {
        //console.log(`Collected ${reaction.emoji.name} from ${user.tag}`);
        if (reaction.emoji.name == "⬅️") {
          index = Math.min(Math.max(parseInt(index)-1, 0), numresults-1)
          embed
            .setImage(r34posts[index].file_url)
            .setFooter("Page " + (index+1) + "/" + numresults)
          collector.message.edit(embed)
        }
        else if (reaction.emoji.name == "➡️") {
          index = Math.min(Math.max(parseInt(index)+1, 0), numresults-1)
          embed
            .setImage(r34posts[index].file_url)
            .setFooter("Page " + (index+1) + "/" + numresults)
          collector.message.edit(embed)
        }
      })
      collector.on('remove', (reaction, user) => {
        if (reaction.emoji.name == "⬅️") {
          index = Math.min(Math.max(parseInt(index)-1, 0), numresults-1)
          embed
            .setImage(r34posts[index].file_url)
            .setFooter("Page " + (index+1) + "/" + numresults)
          collector.message.edit(embed)
        }
        else if (reaction.emoji.name == "➡️") {
          index = Math.min(Math.max(parseInt(index)+1, 0), numresults-1)
          embed
            .setImage(r34posts[index].file_url)
            .setFooter("Page " + (index+1) + "/" + numresults)
          collector.message.edit(embed)
        }
      })
      collector.on('end', collected => {
        collector.message.edit("Timed out, you have not pressed a button in the last 30 seconds!")
      })
    })
    /*
    {
      height: 2276,
      score: 1,
      file_url: 'https://us.rule34.xxx/images/4083/8587ef746a7220058c059800dcabd7d4.jpeg',
      parent_id: '',
      sample_url: 'https://us.rule34.xxx/images/4083/8587ef746a7220058c059800dcabd7d4.jpeg',
      sample_width: 1280,
      sample_height: 2276,
      preview_url: 'https://us.rule34.xxx/thumbnails/4083/thumbnail_8587ef746a7220058c059800dcabd7d4.jpg',
      rating: 'e',
      tags: ' athletic athletic_male bara biceps big_balls big_butt big_muscles big_penis blowjob bodybuilder calves cum cumshot full_service gay hunk jock male male/male male_only manly mazjojo muscles nude pecs thick_cum thick_legs thick_penis thick_thighs ',
      id: 4635705,
      width: 1280,
      change: 1618434108,
      md5: '8587ef746a7220058c059800dcabd7d4',
      creator_id: 957479,
      has_children: false,
      created_at: 'Wed Apr 14 21:01:48 +0000 2021',
      status: 'active',
      source: '',
      has_notes: false,
      has_comments: false,
      preview_width: 84,
      preview_height: 150,
      tags_parsed: [Array]
    }
    */
  },
};

