const Discord = require('discord.js');
const Util = Discord.Util
const Sequelize = require('sequelize');

const sequelize = new Sequelize('database', null, null, {
	dialect: 'sqlite',
	logging: false,
	storage: 'resources/tags.sqlite',
});


const Tags = sequelize.define('tags', {
	name: {
		type: Sequelize.TEXT,
		unique: true,
	},
	content: Sequelize.TEXT,
	userid: Sequelize.TEXT,
    username: Sequelize.TEXT,
	usage_count: {
		type: Sequelize.INTEGER,
		defaultValue: 0,
		allowNull: false,
	},
});

Tags.sync();

module.exports = {
    //Command Information
    name: "tag",
    description: "tag <name> - responds with the content of the tag\ntag add <name> <content> - creates a tag with the specified content\ntag edit <name> <content> - edits a tag\ntag remove <name> - removes a tag that you own\ntag info <name> - shows info about a tag",
    usage: "tag <tag name or command> <argument if command>",
    enabled: true,
    aliases: [],
    category: "Fun",
    memberPermissions: [],
    botPermissions: [ "SEND_MESSAGES", "EMBED_LINKS" ],
    nsfw: false,
    cooldown: 5000,
    ownerOnly: false,

    async execute(client, message, args, data) {
        //console.log(args)
        arg = args.shift().toLowerCase()
        if(args.length === 0){
            if (arg === undefined) {
                message.reply("\`\`\`\n<prefix>tag <name> - responds with the content of the tag\n<prefix>tag add <name> <content> - creates a tag with the specified content\n<prefix>tag edit <name> <content> - edits a tag\n<prefix>tag remove <name> - removes a tag that you own\n<prefix>tag info <name> - shows info about a tag\n\`\`\`")
                return
            }
            const tag = await Tags.findOne({ where: { name: arg } })
            if (tag) {
                // equivalent to: UPDATE tags SET usage_count = usage_count + 1 WHERE name = 'tagName';
                tag.increment('usage_count')
                embed = new Discord.MessageEmbed()
                .setTitle(tag.name)
                .setDescription(tag.get('content'))
                .setFooter(`Requested by ${message.author.tag} (${tag.userid})`)
                message.channel.send(embed)
                //console.log(tag.get('content'))
                return;
            }
            message.reply(Util.removeMentions(`Could not find tag: \`${arg}\``))
            return;
        }
        switch (arg) {
            case "add":
                tagName = args.shift().toLowerCase()
                tagContent = args.join(" ")
                //console.log("name:",tagName,"content:",tagContent)
                if(tagContent == ""){
                    return message.reply("You can't create a tag with no content!")
                }
                try {
                    // equivalent to: INSERT INTO tags (name, descrption, username) values (?, ?, ?);
                    const tag = await Tags.create({
                        name: tagName,
                        content: tagContent,
                        userid: message.author.id,
                        username: message.author.tag
                    });
                    return message.reply(Util.removeMentions(`Tag \`${tag.name}\` added.`));
                } catch (e) {
                    if (e.name === 'SequelizeUniqueConstraintError') {
                        return message.reply('That tag already exists!');
                    }
                    console.error(e)
                    return message.reply('Something went wrong with adding a tag.');
                }
                break;
            case "edit":
                tagName = args.shift().toLowerCase()
                tagContent = args.join(" ")
                if(tagContent == ""){
                    return message.reply("You can't edit a tag with no content!")
                }
                // equivalent to: UPDATE tags (descrption) values (?) WHERE name = ?;
                const affectedRows = await Tags.update({ content: tagContent }, { where: { name: tagName } });
                if (affectedRows > 0) {
                    message.reply(Util.removeMentions(`Edited tag \`${tagName}\``));
                    break;
                }
                message.reply(Util.removeMentions(`Could not find a tag with name \`${tagName}\`.`));
                break;
            case "remove":
                tagName = args.shift().toLowerCase()
                const rowCount = await Tags.destroy({ where: { name: tagName } });
                if (!rowCount) {message.reply('That tag did not exist.'); break;}
                message.reply('Tag deleted.');
                break;
            case "info":
                tagName = args.shift().toLowerCase()
                const tag = await Tags.findOne({ where: { name: tagName } });
                if (tag) {
                    return message.reply(Util.removeMentions(`${tagName} was created by ${tag.username} (${tag.userid}) at ${tag.createdAt} and has been used ${tag.usage_count} times.`));
                }
                return message.reply(Util.removeMentions(`Could not find tag: ${tagName}`));
                break;
            default:
                break;
        }
    }
}