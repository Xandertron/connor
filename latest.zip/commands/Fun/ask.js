const cleverbot = require("cleverbot-free");

module.exports = {
    //Command Information
    name: "ask",
    description: "Asks cleverbot a question, or talks to it",
    usage: "ask <query>",
    enabled: true,
    aliases: ["cleverbot"],
    category: "Fun",
    memberPermissions: [],
    botPermissions: ["SEND_MESSAGES"],
    nsfw: false,
    cooldown: 5000,
    ownerOnly: false,

    async execute(client, message, args, data) {
        q = args.join(" ")
        cleverbot(q, [])
            .then(response => {
                message.reply(response)
            })
            .catch(() => {
                message.reply("Sorry, my brain malfunctioned, please try again or submit a bug report with the bug command.")
                console.error("Something went wrong when using cleverbot")
            });
    }
}