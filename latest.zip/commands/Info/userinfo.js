const Discord = require("discord.js"),
  moment = require('moment');

module.exports = {
  //Command Information
  name: "userinfo",
  description: "Get information about a user",
  usage: "userinfo",
  enabled: true,
  aliases: ["user"],
  category: "Info",
  memberPermissions: [],
  botPermissions: ["SEND_MESSAGES", "EMBED_LINKS"],
  nsfw: false,
  cooldown: 3000,
  ownerOnly: false,

  async execute(client, message, args, data) {
    let user = !args[0] ? await client.users.fetch(message.author.id) : await client.users.fetch(client.tools.cleanID(args[0]))

    let createDate = await moment(user.createdAt).format('MMMM Do YYYY, HH:mm:ss');

    let embed = new Discord.MessageEmbed()
      .setAuthor(user.tag, user.displayAvatarURL())
      .setThumbnail(user.displayAvatarURL({ dynamic: true }))
      .addFields(
        { name: `User`, value: `${user} (\`${user.id}\`)`, inline: false },
        { name: `Created`, value: createDate, inline: false },
      )
      .setColor(data.config.color)
      .setFooter(client.randomfooter())

    return message.channel.send(embed)
  },
};
