const sa = require("superagent");
const SteamID = require("steamid");
const SteamAPIKey = ""
const Discord = require("discord.js");

module.exports = {
    //Command Information
    name: "steamid",
    description: "Get info for a Steam user",
    usage: "steamid <id>",
    enabled: true,
    aliases: ["sid"],
    category: "Info",
    memberPermissions: [],
    botPermissions: [ "SEND_MESSAGES", "EMBED_LINKS" ],
    nsfw: false,
    cooldown: 5000,
    ownerOnly: false,

    async execute(client, message, args, data) {
        try { var sid = new SteamID(args[0])
            sa.get(`https://api.steampowered.com/ISteamUser/GetPlayerSummaries/v0002/?key=${SteamAPIKey}&steamids=${sid.getSteamID64()}&q=rfge`).then(
                req => {
                    var data = JSON.parse(req.res.text).response.players[0]
                    //console.log(data)
                    //message.channel.send(data.personaname)
                    var desc = "Online"
                    if(data.personastate === 0){
                        desc = "Offline"
                    }
                    if(data.gameextrainfo != undefined){
                        desc = "Currently playing " + data.gameextrainfo
                        if(data.gameserverip != undefined){
                            desc = desc + "\n    Join with: steam://connect/"+data.gameserverip
                        }
                    }
                    var datecreated = new Date(data.timecreated*1000).toLocaleDateString('en-gb',{year: 'numeric',month: 'long',day: 'numeric'})
                    let embed = new Discord.MessageEmbed()
                        .setColor(0x222222)
                        .setAuthor("SteamID info","https://xandertron.github.io/steamicon.png")
                        .setTitle(data.personaname)
                        .setDescription(desc)
                        .setURL("www.google.com")
                        .setThumbnail(data.avatarfull)
                        .setURL("https://steamcommunity.com/profiles/"+data.steamid)
                        .setFooter("Date created: "+datecreated)
                    
                    message.channel.send(embed)
                }
            );
        }
        catch{ message.channel.send("Invalid Steam ID") }
    }
}
