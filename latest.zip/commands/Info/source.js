const Discord = require('discord.js');
const games = require("../../resources/games.json");
const gd = require("gamedig");

module.exports = {
    //Command Information
    name: "sourceserver",
    description: "Get info about a source server (gmod, tf2, csgo)",
    usage: "sourceserver <ip> [port]",
    enabled: true,
    aliases: ["sserver"],
    category: "Info",
    memberPermissions: [],
    botPermissions: [ "SEND_MESSAGES", "EMBED_LINKS" ],
    nsfw: false,
    cooldown: 3000,
    ownerOnly: true,

    async execute(client, message, args, data) { 
        var nport = (args[1] == undefined) ? 27015 : args[1]
        if (args[0] == undefined) { 
            message.channel.send("You need to specify an IP!")
            return
        }
        gd.query({
            type: "garrysmod",
            host: args[0],
            port: nport,
            maxAttempts: 3
        }).then((state) => {
            str = "\`\`\`\n"
            //console.log(state)
            for (i = 0; i < state.bots.length; i++) {
                str = str + state.bots[i].name + " (BOT)\n"
            }
            for (i = 0; i < state.players.length; i++) {
                ply = state.players[i]
                //console.log(ply.name)
                if (i >= 25) {
                    str = str + "...and " + (state.players.length-25).toString() + " more...\n"
                    break;
                }
                if (ply.name == undefined) {
                    str = str + "(connecting or invalid)" + "\n"
                }
                else{
                    str = str + ply.name + "\n"
                }
            }
            str = str + "\`\`\`"
            //console.log(str)
            let embed = new Discord.MessageEmbed()
                .setColor(0x3399FF)
                .setTitle("Server info")
                .setDescription(state.name)
                .addFields(
                    { name: "Players", value: state.raw.numplayers + "/" + state.maxplayers, inline: true },
                    { name: "Bots", value: state.raw.numbots, inline: true },
                )
                .addField("Dedicated", (state.raw.listentype === "d") ? "Yes" : "No", inline = true)
                .addFields(
                    { name: "Map", value: state.map, inline: true },
                    { name: "Passworded", value: state.password ? "Yes" : "No", inline: true },
                )
                .addField("Vac", state.raw.secure ? "Yes" : "No", inline = true)
                .addField("Player list:",str)
                .setFooter(games[state.raw.folder])

            str = ""
            message.channel.send(embed)
        }).catch((error) => {
            console.log(error)
            message.channel.send("\`Server is offline or not responding after 3 attempts\`");
        });
    }
}

module.exports.config = {
    name: "sourceserver",
    aliases: ["sserver"]
}
