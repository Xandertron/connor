const Discord = require('discord.js');
const mindmotd = require("../../resources/motd.js");

module.exports = {
    //Command Information
    name: "mindustryserver",
    description: "Get info about a mindustry server",
    usage: "mindustryserver <ip> [port]",
    enabled: false,
    aliases: ["mserver"],
    category: "Info",
    memberPermissions: [],
    botPermissions: ["SEND_MESSAGES", "EMBED_LINKS"],
    nsfw: false,
    cooldown: 3000,
    ownerOnly: false,

    async execute(client, message, args, data) {
        try {
            mindmotd.getServerInfo(args[0], args[1]).then(info => {
                var colorremover = new RegExp("\\[.*?\\]", "g");

                let embed = new Discord.MessageEmbed()
                    .setColor(0x3399FF)
                    .setTitle(info.host.replace(colorremover, ""))
                    .setDescription(info.desc.replace(colorremover, ""))
                    .addFields(
                        { name: "Map", value: info.map.replace(colorremover, ""), inline: true },
                        { name: "Version", value: info.gameversion, inline: true },
                        { name: "Players", value: info.players, inline: true },
                        { name: "Wave", value: info.waves, inline: true },
                    )

                message.channel.send(embed)
            })
        }catch{
            message.channel.reply("Either you forgot the ip, port, or it timed out")
        }
    }
}

module.exports.config = {
    name: "mindustryserver",
    aliases: ["mindserver"]
}