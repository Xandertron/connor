const Discord = require("discord.js");
const pm2 = require("pm2")
module.exports = {
    //Command Information
    name: "restart",
    description: "Restarts bot",
    usage: "restart",
    enabled: true,
    aliases: [],
    category: "Testing",
    memberPermissions: [],
    botPermissions: ["SEND_MESSAGES"],
    nsfw: false,
    cooldown: 3000,
    ownerOnly: true,

    async execute(client, message, args, data) {
        message.channel.send("Restarting...")
        pm2.restart("app")
    }
}