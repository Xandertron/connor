const Discord = require("discord.js");

module.exports = {
    //Command Information
    name: "middle",
    description: "Sends a wip reaction test, for later use of pages",
    usage: "middle",
    enabled: false,
    aliases: [],
    category: "Testing",
    memberPermissions: [],
    botPermissions: ["SEND_MESSAGES", "EMBED_LINKS"],
    nsfw: false,
    cooldown: 3000,
    ownerOnly: false,
    hidden: true,

    async execute(client, message, args, data) {
        message.channel.send("middle!").then(repsonse => {
            repsonse.react("⬅️") //<--
                .then(() => repsonse.react("➡️")) //-->
                .then(() => {
                    const filter = (reaction, user) => {
                        return user.id === message.author.id;
                    };

                    const collector = repsonse.createReactionCollector(filter, { idle: 30000, dispose: true });
                    collector.on('collect', (reaction, user) => {
                        //console.log(`Collected ${reaction.emoji.name} from ${user.tag}`);
                        if (reaction.emoji.name == "⬅️") {
                            collector.message.edit("left!" + testvarible)
                        }
                        else if (reaction.emoji.name == "➡️") {
                            collector.message.edit("right!" + testvarible)
                        }
                    });
                    collector.on('remove', (reaction, user) => {
                        //console.log(`Collected ${reaction.emoji.name} from ${user.tag}`);
                        if (reaction.emoji.name == "⬅️") {
                            collector.message.edit("left")
                        }
                        else if (reaction.emoji.name == "➡️") {
                            collector.message.edit("right")
                        }
                    });

                    collector.on('end', collected => {
                        collector.message.edit("timeout!")
                    });
                })
        })
    }
}
