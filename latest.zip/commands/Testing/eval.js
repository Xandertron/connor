const Discord = require("discord.js");
const perf = require('perf_hooks').performance
const inspect = require("util").inspect
module.exports = {
    //Command Information
    name: "evaluate",
    description: "Evaluates javascript",
    usage: "evaluate <js>",
    enabled: true,
    aliases: ["eval", "js"],
    category: "Testing",
    memberPermissions: [],
    botPermissions: ["SEND_MESSAGES", "ATTACH_FILES"],
    nsfw: false,
    cooldown: 3000,
    ownerOnly: true,

    async execute(client, message, args, data) {
        try {
            var t1 = perf.now()
            evaled = await eval(args.join(" "))
            var t2 = perf.now()
            if (typeof evaled !== "string") {
                evaled = inspect(evaled)
            }
            evaled = evaled.replace(client.token, "[redacted]")
            if (evaled.length > 2000) {
                let embed = new Discord.MessageEmbed()
                    .setTitle("Result:")
                    .setDescription(`\`\`\`\nLength is too long for discord, uploading it as .txt\n\`\`\``)
                    .setFooter(`Evaluation took ${t2 - t1}ms.`)
                attachment = new Discord.MessageAttachment(Buffer.from(evaled, "utf-8"), "result.js") 
                return message.channel.send(embed).then(message.channel.send(attachment))
            }
            let embed = new Discord.MessageEmbed()
                .setTitle("Result:")
                .setDescription(`\`\`\`\n${evaled}\n\`\`\``)
                .setFooter(`Evaluation took ${t2 - t1}ms.`)
            message.channel.send(embed)
        }
        catch (e) {
            let embed = new Discord.MessageEmbed()
                .setTitle("Error:")
                .setDescription(`\`\`\`\n${e}\n\`\`\``)
            message.channel.send(embed)
            //console.log("Something went wrong")
        }

    }
}