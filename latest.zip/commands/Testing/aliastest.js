module.exports = {
    //Command Information
    name: "alias",
    description: "aliases test",
    usage: "none",
    enabled: false,
    aliases: ["aliasone", "aliastwo", "alias3"],
    category: "Testing",
    memberPermissions: [],
    botPermissions: [ "SEND_MESSAGES" ],
    nsfw: false,
    cooldown: 3000,
    ownerOnly: false,
    hidden: true,

    async execute(client, message){
        message.reply("yes they are valid commands")
    }
}