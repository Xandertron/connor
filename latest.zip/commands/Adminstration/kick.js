const Discord = require('discord.js');

module.exports = {

    //Information about command
    name: "kick",
    description: "Kick a user from your server",
    usage: "kick <mention> [reason]",
    enabled: true,
    aliases: [],
    category: "Adminstration",
    memberPermissions: ["KICK_MEMBERS"],
    botPermissions: ["KICK_MEMBERS", "SEND_MESSAGES"],
    //Settings for command
    nsfw: false,
    ownerOnly: false,
    cooldown: 5000,
    serverOnly: true,

    //Execute to command once the settings have been checked
    async execute(client, message, args, data) {
        const user = message.mentions.users.first();

        if (user == client.user){
            return message.channel.send("Unfortunately I cannot kick myself")
        }

        // If we have a user mentioned
        if (user) {
            // Now we get the member from the user
            const member = message.guild.members.resolve(user);
            // If the member is in the guild
            if (member) {
                /**
                 * Kick the member
                 * Make sure you run this on a member, not a user!
                 * There are big differences between a user and a member
                 */
                reason = args.splice(1).join(" ")
                member
                    .kick(`Initiated by: @${message.author.tag} (${message.author.id}) Reason: ${(reason) ? reason : "None specified"}`)
                    .then(() => {
                        // We let the message author know we were able to kick the person
                        console.log(args)
                        message.channel.send(`Successfully kicked ${user.tag}${(reason) ? (" with the reason: " + reason) : ""}`);
                    })
                    .catch(err => {
                        // An error happened
                        // This is generally due to the bot not being able to kick the member,
                        // either due to missing permissions or role hierarchy
                        message.channel.send(`I was unable to kick \`${user.tag}\`, they may have higher roles than me.`);
                        // Log the error
                        console.error(err);
                    });
            } else {
                // The mentioned user isn't in this guild
                message.channel.send("That user isn't in this guild!");
            }
            // Otherwise, if no user was mentioned
        } else {
            message.channel.send("You didn't mention the user to kick!");
        }
    },
};
