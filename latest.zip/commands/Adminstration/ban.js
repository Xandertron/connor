const Discord = require('discord.js');

module.exports = {

  //Information about command
  name: "ban",
  description: "Ban a user",
  usage: "ban <mention/id>",
  enabled: true,
  aliases: ["prefix"],
  category: "Adminstration",
  memberPermissions: ["BAN_MEMBERS"],
  botPermissions: ["BAN_MEMBERS", "SEND_MESSAGES"],
  //Settings for command
  nsfw: false,
  ownerOnly: false,
  cooldown: 5000,
  serverOnly: true,

  //Execute to command once the settings have been checked
  async execute(client, message, args, data) {
    ID = client.tools.cleanID(args[0])
    user = await client.users.fetch(ID)
    if (ID == client.user.id) {
      return message.reply("Unfortunately, I cannot ban myself")
    }
    try {
      info = await message.channel.guild.fetchBan(user)
      if (info) {
        return message.reply(`\`${user.tag}\` is already banned!`)
      }
    } catch (e) {}
    reason = args.splice(1).join(" ")
    message.channel.guild.members
      .ban(ID, { reason: `Initiated by: @${message.author.tag} (${message.author.id}) Reason: ${(reason) ? reason : "None specified"}` })
      .then(() => {
        // We let the message author know we were able to kick the person
        message.reply(`Successfully banned \`${user.tag}\`${(reason) ? (" with the reason: " + reason) : ""}`);
      })
      .catch(err => {
        // An error happened
        // This is generally due to the bot not being able to kick the member,
        // either due to missing permissions or role hierarchy
        message.channel.send(`I was unable to ban \`${user.tag}\`, they may have higher roles than me.`);
        // Log the error
        console.error(err);
      });
  },
};
