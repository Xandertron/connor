const customisation = require('../../config.json');

module.exports = {
    //Command Information
    name: "bug",
    description: "Sends a bug report",
    usage: "bug",
    enabled: true,
    aliases: [],
    category: "Bot",
    memberPermissions: [],
    botPermissions: ["SEND_MESSAGES"],
    nsfw: false,
    cooldown: 3000,
    ownerOnly: false,

    async execute(client, message, args) {
        if (!args[0]) return message.reply("Please specify the bug. Example:\n`8ball isn't working. It won't tell me it's opinion`");
        if (args.length < 3) return message.reply("Please be more specific, more than 2 words are needed");
        args = args.join(" ");
        message.reply("Thanks for submitting a bug!");
        const content = `**${message.author.tag} (${message.author.id})** reported:\n~~--------------------------------~~\n${args}\n~~--------------------------------~~\nOrigin: **${(!message.guild) ? "Direct message" : "Server (" + message.guild.id + ")"}**`;
        client.channels.cache.get(customisation.bugchannelid).send(content)
    }
}
