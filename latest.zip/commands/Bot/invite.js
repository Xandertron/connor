const Discord = require("discord.js");

module.exports = {
    //Command Information
    name: "info",
    description: "Get various links related to me, including invite and support",
    usage: "info",
    enabled: true,
    aliases: ["invite", "invitation", "support", "add", "info", "vote"],
    category: "Bot",
    memberPermissions: [],
    botPermissions: [ "SEND_MESSAGES", "EMBED_LINKS" ],
    nsfw: false,
    cooldown: 3000,
    ownerOnly: false,

    async execute(client, message, args) {
        let embed = new Discord.MessageEmbed()
            .setDescription("[Support server](https://discord.gg/P2PeTUBffk)\nInvite: [Recommended permissions](https://discord.com/oauth2/authorize?client_id=764217610438180895&scope=bot&permissions=272454) // [No permissions](https://discord.com/oauth2/authorize?client_id=764217610438180895&scope=bot&permissions=0)\nVote: [top.gg](https://top.gg/bot/764217610438180895/vote) // [discordbotlist.com](https://discordbotlist.com/bots/connor/upvote)")
            .setFooter("Kick and ban (banning by id) permissions are needed for relevent commands\nManage messages are for clearing bot reactions")
        message.channel.send(embed)
    }
}