//i believe this was used for prom/graphana
const http = require('http')
const promclient = require('prom-client')
const register = new promclient.Registry()
register.setDefaultLabels({
	app: 'Connor'
})
promclient.collectDefaultMetrics({ register })

const eventcounter = new promclient.Counter({
	name: 'events',
	help: 'events',
	registers: [register],
	labelNames: ['event'],
});

const wslatency = new promclient.Gauge({
	name: "latency",
	help: "latency",
	registers: [register],
	collect () {
		this.set(globaldiscordclient.ws.ping)
	}
})

module.exports = async (dclient, raw) => {
	try {
		if (raw.t !== null) {
			//console.log("Received: " + raw.t)
			eventcounter.inc({ event: raw.t }, 1);
		}
	} catch (e) {
		console.log("error idk lol\n", e)
	}
}

const server = http.createServer(async (req, res) => {
	//console.log(req.url)
	if (req.url === '/metrics') {
		res.setHeader('Content-Type', register.contentType)
		metrics = await register.metrics()
		res.end(metrics)
	}
	else {
		res.end("404")
	}
})
server.listen(8080)
