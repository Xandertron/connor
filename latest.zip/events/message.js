const Discord = require("discord.js");
const config = require("./../config.json");
let cmdCooldown = {};

module.exports = async (client, message) => {
  try {
    //If author is a bot then return
    if (message.author.bot) return;

    //If the message isn't in a guild return following message
    //if(!message.guild){
    //  return message.channel.send("Please use my commands in your guild as they do not work in direct messages. Using `v!help` in your server to get started.")
    //}

    //Get guild database
    let prefix
    let guildDB
    let dm
    try {
      guildDB = await client.data.getGuildDB(message.guild.id)
      dm = false
      //Get prefix from guild else get from config file
      prefix = !guildDB.prefix ? config.prefix : guildDB.prefix
    } catch (err) {
      //We're probably in a fucking dm or something
      prefix = config.prefix
      dm = true
    }
    //Check if message starts with the prefix
    if (!message.content.toLowerCase().startsWith(prefix)) {
      if (message.content === `<@!${message.client.user.id}>` || message.content === `<@${message.client.user.id}>`) {
        if (dm) {
          return message.reply(`Hello! My prefix in DMs is \`${prefix}\`, and if you need help, use \`${prefix}help\``)
        }
        return message.reply(`Hello! My prefix on this server is set to \`${prefix}\`, and if you need help, use \`${prefix}help\`, alternatively you can change it with \`${prefix}setprefix\` if you are an admin.`)
      }
      return;
    }

    //Checking if the message is a command
    const args = message.content.slice(prefix.length).trim().split(/ +/g)
    const commandName = args.shift().toLowerCase()
    const cmd = client.commands.get(commandName) || client.commands.find(cmd => cmd.aliases && cmd.aliases.includes(commandName));

    //If it isn't a command then return
    if (!cmd) return;

    //Get the user database
    let userDB = await client.data.getUserDB(message.author.id)
    let data = {}
    data.config = config
    data.user = userDB
    if (!dm) {
      data.guild = guildDB
    }
    data.cmd = cmd

    //If channel isn't nsfw and command is return error
    if (!message.channel.nsfw && cmd.nsfw && message.guild) {
      return client.errors.errorinfo(message.channel, 4)
    }

    //If command is owner only and author isn't owner return
    if (cmd.ownerOnly && message.author.id !== config.ownerid) {
      return client.errors.errorinfo(message.channel, 5)
    }

    if (cmd.serverOnly && (!message.guild)) {
      return client.errors.errorinfo(message.channel, 6)
    }

    if (message.guild) {

      let userPerms = []

      //Checking for members permission
      cmd.memberPermissions.forEach((perm) => {
        if (!message.channel.permissionsFor(message.member).has(perm)) {
          userPerms.push(perm);
        }
      });

      //If user permissions arraylist length is more than one return error
      if (userPerms.length > 0 && !message.member.roles.cache.find((r) => r.name.toLowerCase() === config.adminRole.toLowerCase())) {
        client.logger.cmd(`${message.author.tag} used ${cmd.name} - User MP`);
        return message.channel.send("Looks like you are missing the following permissions:\n" + userPerms.map((p) => `\`${client.perms[p]}\``).join(", "));
      }

      let clientPerms = [];

      //Checking for client permissions
      cmd.botPermissions.forEach((perm) => {
        if (!message.channel.permissionsFor(message.guild.me).has(perm)) {
          clientPerms.push(perm);
        }
      });

      //If client permissions arraylist length is more than one return error
      if (clientPerms.length > 0) {
        client.logger.cmd(`${message.author.tag} used ${cmd.name} - Bot MP`);
        return message.channel.send("Looks like I am missing the following permissions:\n" + clientPerms.map((p) => `\`${client.perms[p]}\``).join(", "));
      }

    }

    let uCooldown = cmdCooldown[message.author.id];

    if (!uCooldown) {
      cmdCooldown[message.author.id] = {};
      uCooldown = cmdCooldown[message.author.id];
    }

    let time = uCooldown[cmd.name] || 0;
    //Check if user has a command cooldown
    if (time && (time > Date.now())) {
      let timeLeft = Math.ceil((time - Date.now()) / 1000);
      return message.reply(`Slow down! Please wait \`${timeLeft}s\` before using this command again!`)
    }

    cmdCooldown[message.author.id][cmd.name] = Date.now() + cmd.cooldown;

    //Create a new log for the command
    client.data.getLogDB(message.author, message.guild, cmd);
    //Execute the command and log the user in console
    cmd.execute(client, message, args, data);
    client.logger.cmd(`${(!message.guild) ? "(DM) " : ""}${message.author.tag} used ${cmd.name}`);

  } catch (err) {
    console.error(err);
  }

};
