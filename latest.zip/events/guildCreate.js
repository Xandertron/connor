//logged to my dev server if i joined a server not, small bot problems amirite
module.exports = async(client, guild) => {
    client.channels.cache.get("837350250523394128").send("It appears i have joined a guild called: \`"+guild.name+"\` with "+guild.memberCount+" members!")
}