module.exports = async(client, guild) => {
    client.channels.cache.get("837350250523394128").send("It appears i have left a guild called: \`"+guild.name+"\` with "+guild.memberCount+" members!")
}